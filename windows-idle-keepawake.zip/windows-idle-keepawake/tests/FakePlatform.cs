using System;
using System.Collections.Generic;
using IdleKeepAwake;

namespace IdleKeepAwakeTests
{
    public sealed class FakePlatform : IPlatform
    {
        public InputSnapshot State = new InputSnapshot(0, 0, false, true);
        public readonly Queue<InputSnapshot> Readings = new Queue<InputSnapshot>();
        public int PowerCalls;
        public int MoveCalls;
        public bool MoveSucceeds = true;
        public bool RecordSyntheticInput;
        public bool FailPower;
        public bool FailRead;
        public ulong Now { get { return State.Now; } }
        public InputSnapshot ReadInput()
        {
            if (FailRead) { throw new InvalidOperationException("read failure"); }
            return Readings.Count == 0 ? State : Readings.Dequeue();
        }
        public void RefreshSleepPrevention()
        {
            PowerCalls++;
            if (FailPower) { throw new InvalidOperationException("power failure"); }
        }
        public bool NudgeMouse()
        {
            MoveCalls++;
            if (MoveSucceeds && RecordSyntheticInput)
            {
                State.LastInput = unchecked((uint)State.Now);
            }
            return MoveSucceeds;
        }
    }
}

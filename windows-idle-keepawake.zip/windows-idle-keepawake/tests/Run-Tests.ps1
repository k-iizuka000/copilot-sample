#requires -Version 5.1
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$script:passed = 0

function Assert-Equal($Expected, $Actual) {
    if ($Expected -ne $Actual) { throw "Expected [$Expected], got [$Actual]" }
}
function Test-Case([string]$Name, [scriptblock]$Body) {
    & $Body
    $script:passed++
    Write-Output "PASS $Name"
}
function New-Snapshot([ulong]$Now, [uint32]$LastInput, [bool]$Held = $false, [bool]$Available = $true) {
    New-Object IdleKeepAwake.InputSnapshot($Now, $LastInput, $Held, $Available)
}
function New-Fake { New-Object IdleKeepAwakeTests.FakePlatform }
function New-Engine($Platform) { New-Object IdleKeepAwake.Engine($Platform) }

Test-Case 'All PowerShell scripts parse' {
    Get-ChildItem $root -Recurse -Filter '*.ps1' | ForEach-Object {
        $tokens = $null
        $parseErrors = $null
        $null = [System.Management.Automation.Language.Parser]::ParseFile($_.FullName, [ref]$tokens, [ref]$parseErrors)
        if ($parseErrors.Count -gt 0) { throw ($parseErrors | Out-String) }
    }
}

$sources = @((Join-Path $root 'KeepAwake.cs'), (Join-Path $PSScriptRoot 'FakePlatform.cs'))
if ($PSVersionTable.PSVersion.Major -ge 7) {
    Add-Type -Path $sources -CompilerOptions '/langversion:5'
}
else {
    Add-Type -Path $sources
}
Test-Case 'Production C# compiles (C# 5 on PowerShell 7)' {
    Assert-Equal 180000 ([IdleKeepAwake.IdlePolicy]::IntervalMilliseconds)
}

Test-Case 'No movement at startup, 179 seconds, or 179999 ms; move at 180000 ms' {
    $fake = New-Fake
    $engine = New-Engine $fake
    foreach ($time in @(0, 179000, 179999)) {
        $fake.State = New-Snapshot $time 0
        Assert-Equal Waiting ($engine.Tick())
    }
    $fake.State = New-Snapshot 180000 0
    Assert-Equal Moved ($engine.Tick())
    Assert-Equal 1 $fake.MoveCalls
}

Test-Case 'Fresh input at 179999 ms restarts the full wait' {
    $fake = New-Fake
    $engine = New-Engine $fake
    foreach ($time in @(180000, 359998)) {
        $fake.State = New-Snapshot $time 179999
        Assert-Equal Waiting ($engine.Tick())
    }
    $fake.State = New-Snapshot 359999 179999
    Assert-Equal Moved ($engine.Tick())
}

Test-Case 'An already idle session still waits 3 minutes after launching' {
    $fake = New-Fake
    $fake.State = New-Snapshot 1000000 0
    $engine = New-Engine $fake
    Assert-Equal Waiting ($engine.Tick())
    $fake.State = New-Snapshot 1179999 0
    Assert-Equal Waiting ($engine.Tick())
    $fake.State = New-Snapshot 1180000 0
    Assert-Equal Moved ($engine.Tick())
}

Test-Case 'Synthetic input not recorded by Windows never causes repeated polling movements' {
    $fake = New-Fake
    $engine = New-Engine $fake
    for ($second = 1; $second -le 21600; $second++) {
        $fake.State = New-Snapshot ($second * 1000) 0
        $null = $engine.Tick()
    }
    Assert-Equal 120 $fake.MoveCalls
    Assert-Equal 21600 $fake.PowerCalls
}

Test-Case 'Six hours idle with synthetic-input timestamps also moves exactly every 3 minutes' {
    $fake = New-Fake
    $fake.RecordSyntheticInput = $true
    $engine = New-Engine $fake
    for ($second = 1; $second -le 21600; $second++) {
        $fake.State = New-Snapshot ($second * 1000) $fake.State.LastInput
        $null = $engine.Tick()
    }
    Assert-Equal 120 $fake.MoveCalls
    Assert-Equal 21600000 $fake.State.LastInput
}

Test-Case '24 hours with user input every 2 minutes never moves the mouse' {
    $fake = New-Fake
    $engine = New-Engine $fake
    for ($second = 1; $second -le 86400; $second++) {
        $last = [uint32]([Math]::Floor($second / 120) * 120000)
        $fake.State = New-Snapshot ($second * 1000) $last
        $null = $engine.Tick()
    }
    Assert-Equal 0 $fake.MoveCalls
    Assert-Equal 86400 $fake.PowerCalls
}

Test-Case 'Input resumed after a nudge takes priority over the old schedule' {
    $fake = New-Fake
    $engine = New-Engine $fake
    $fake.State = New-Snapshot 180000 0
    Assert-Equal Moved ($engine.Tick())
    $fake.State = New-Snapshot 360000 359000
    Assert-Equal Waiting ($engine.Tick())
    $fake.State = New-Snapshot 539000 359000
    Assert-Equal Moved ($engine.Tick())
}

Test-Case 'Input resumes between the initial and final read: cancel the nudge' {
    $fake = New-Fake
    $engine = New-Engine $fake
    $fake.State = New-Snapshot 180000 0
    $fake.Readings.Enqueue((New-Snapshot 180000 0))
    $fake.Readings.Enqueue((New-Snapshot 180001 180001))
    Assert-Equal Waiting ($engine.Tick())
    Assert-Equal 0 $fake.MoveCalls
}

Test-Case 'A regressing input timestamp between reads is also treated as new input' {
    $fake = New-Fake
    $engine = New-Engine $fake
    $fake.Readings.Enqueue((New-Snapshot 400000 100000))
    $fake.Readings.Enqueue((New-Snapshot 400001 99999))
    Assert-Equal Waiting ($engine.Tick())
    Assert-Equal 0 $fake.MoveCalls
}

Test-Case 'A held mouse button, keyboard key, or modifier prevents a nudge' {
    $fake = New-Fake
    $engine = New-Engine $fake
    $fake.State = New-Snapshot 180000 0 $true
    Assert-Equal Waiting ($engine.Tick())
    $fake.State = New-Snapshot 400000 0 $true
    Assert-Equal Waiting ($engine.Tick())
    Assert-Equal 0 $fake.MoveCalls
}

Test-Case 'A key pressed during final confirmation prevents a nudge' {
    $fake = New-Fake
    $engine = New-Engine $fake
    $fake.Readings.Enqueue((New-Snapshot 180000 0))
    $fake.Readings.Enqueue((New-Snapshot 180001 0 $true))
    Assert-Equal Waiting ($engine.Tick())
    Assert-Equal 0 $fake.MoveCalls
}

Test-Case 'An unavailable input desktop prevents mouse injection' {
    $fake = New-Fake
    $engine = New-Engine $fake
    $fake.State = New-Snapshot 180000 0 $false $false
    Assert-Equal Waiting ($engine.Tick())
    Assert-Equal 0 $fake.MoveCalls
    Assert-Equal 1 $fake.PowerCalls
}

Test-Case 'Desktop becoming unavailable during final confirmation cancels movement' {
    $fake = New-Fake
    $engine = New-Engine $fake
    $fake.Readings.Enqueue((New-Snapshot 180000 0))
    $fake.Readings.Enqueue((New-Snapshot 180001 0 $false $false))
    Assert-Equal Waiting ($engine.Tick())
    Assert-Equal 0 $fake.MoveCalls
}

Test-Case 'Rejected / partial input is reported, throttled, and can recover' {
    $fake = New-Fake
    $engine = New-Engine $fake
    $fake.MoveSucceeds = $false
    $fake.State = New-Snapshot 180000 0
    Assert-Equal InputBlocked ($engine.Tick())
    $fake.State = New-Snapshot 181000 0
    Assert-Equal Waiting ($engine.Tick())
    $fake.State = New-Snapshot 359999 0
    Assert-Equal Waiting ($engine.Tick())
    Assert-Equal 1 $fake.MoveCalls
    $fake.MoveSucceeds = $true
    $fake.State = New-Snapshot 360000 0
    Assert-Equal Moved ($engine.Tick())
    Assert-Equal 2 $fake.MoveCalls
}

Test-Case '32-bit tick rollover preserves the 180000 ms boundary' {
    $beforeWrap = [uint32]4294867296
    Assert-Equal 179999 ([IdleKeepAwake.IdlePolicy]::IdleMilliseconds([ulong]4295047295, $beforeWrap))
    Assert-Equal 180000 ([IdleKeepAwake.IdlePolicy]::IdleMilliseconds([ulong]4295047296, $beforeWrap))
    $fake = New-Fake
    $fake.State = New-Snapshot 4294867296 $beforeWrap
    $engine = New-Engine $fake
    $fake.State = New-Snapshot 4295047295 $beforeWrap
    Assert-Equal Waiting ($engine.Tick())
    $fake.State = New-Snapshot 4295047296 $beforeWrap
    Assert-Equal Moved ($engine.Tick())
}

Test-Case 'The signed 32-bit boundary does not affect the idle duration' {
    Assert-Equal 180000 ([IdleKeepAwake.IdlePolicy]::IdleMilliseconds([ulong]2147500000, [uint32]2147320000))
}

Test-Case 'Future / inconsistent last-input timestamps do not trigger mouse input' {
    Assert-Equal 0 ([IdleKeepAwake.IdlePolicy]::IdleMilliseconds(200000, 200001))
    $fake = New-Fake
    $engine = New-Engine $fake
    $fake.State = New-Snapshot 200000 200001
    Assert-Equal Waiting ($engine.Tick())
    Assert-Equal 0 $fake.MoveCalls
}

Test-Case 'Power API failure aborts the tick before input is sent' {
    $fake = New-Fake
    $engine = New-Engine $fake
    $fake.State = New-Snapshot 180000 0
    $fake.FailPower = $true
    $failed = $false
    try { $null = $engine.Tick() } catch { $failed = $true }
    Assert-Equal $true $failed
    Assert-Equal 0 $fake.MoveCalls
}

Test-Case 'Input-time API failure aborts the tick before input is sent' {
    $fake = New-Fake
    $engine = New-Engine $fake
    $fake.State = New-Snapshot 180000 0
    $fake.FailRead = $true
    $failed = $false
    try { $null = $engine.Tick() } catch { $failed = $true }
    Assert-Equal $true $failed
    Assert-Equal 0 $fake.MoveCalls
}

Test-Case 'Native INPUT and MOUSEINPUT sizes and offsets match pointer width' {
    $size = [System.Runtime.InteropServices.Marshal]::SizeOf([type][IdleKeepAwake.MouseEvent])
    $offset = [System.Runtime.InteropServices.Marshal]::OffsetOf([type][IdleKeepAwake.MouseEvent], 'mi').ToInt32()
    $mouseSize = [System.Runtime.InteropServices.Marshal]::SizeOf([type][IdleKeepAwake.MouseInput])
    if ([IntPtr]::Size -eq 8) {
        Assert-Equal 40 $size
        Assert-Equal 8 $offset
        Assert-Equal 32 $mouseSize
    } else {
        Assert-Equal 28 $size
        Assert-Equal 4 $offset
        Assert-Equal 24 $mouseSize
    }
}

Test-Case 'The real event builder sends only paired tiny relative movements' {
    $events = [IdleKeepAwake.WindowsPlatform]::CreateNudge()
    Assert-Equal 2 $events.Count
    Assert-Equal 1 $events[0].mi.dx
    Assert-Equal -1 $events[1].mi.dx
    foreach ($event in $events) {
        Assert-Equal 0 $event.type
        Assert-Equal 0 $event.mi.dy
        Assert-Equal 0 $event.mi.mouseData
        Assert-Equal 0x2001 $event.mi.dwFlags
        Assert-Equal 0 $event.mi.time
        Assert-Equal ([UIntPtr]::Zero) $event.mi.dwExtraInfo
    }
}

Write-Output "RESULT: $script:passed tests passed. OS mouse/power calls were simulated; no real mouse was moved."

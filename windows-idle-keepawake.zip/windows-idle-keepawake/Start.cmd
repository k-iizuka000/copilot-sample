@echo off
setlocal DisableDelayedExpansion
title Idle Keep Awake
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0KeepAwake.ps1"
if errorlevel 1 (
    echo.
    echo Could not run Idle Keep Awake. See the error above and README.md.
    pause
)
endlocal

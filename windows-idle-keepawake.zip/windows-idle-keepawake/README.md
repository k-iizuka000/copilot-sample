# Idle Keep Awake（Windows専用）

マウス・キーボードの入力が3分間途切れたときだけ、マウスをわずかに往復させます。起動中はWindows標準APIで自動スリープと画面の自動消灯も抑止します。

## 使い方

1. ZIPをWindows端末へコピーし、右クリック → **すべて展開**します。
2. 展開したフォルダ内の **`Start.cmd` をダブルクリック**します。
3. `Idle Keep Awake is RUNNING.` と表示されたら起動完了です。ウィンドウは最小化してかまいません。
4. 終了するときは、そのウィンドウを **×で閉じる**か、そのウィンドウ内で **Ctrl+C** を押します。

通常、インストールや管理者権限は不要です。Windows PowerShell 5.1が利用できるWindows 10 / 11を想定しています。実行に必要な `Start.cmd`、`KeepAwake.ps1`、`KeepAwake.cs` は同じフォルダに置いてください。`.ps1` 単体はダブルクリックでエディターが開くことがあるため、`Start.cmd` を入口にしています。

## 動き方

- 最後の入力から180秒以上経過したら、小さな相対移動を右・左の順でまとめて送ります。クリック、スクロール、文字入力は送りません。
- 1秒ごとに確認するため、通常の判定は無入力開始から約180〜181秒後です。高負荷やOSの中断で遅れることがあります。
- 途中でマウスやキーボードを操作すると、その入力から再び3分待ちます。起動直後も最低3分待ちます。
- 放置し続けた場合は、おおむね3分ごとに繰り返します。自動入力がWindowsの最終入力時刻に反映されなくても連続実行しません。
- キーやマウスボタンを押したままの場合は移動を見送ります。移動直前にも入力状態を確認します。
- 同じWindowsログインセッション内で二重に起動しても、動く本体は1つです。
- ネット接続、入力内容の保存、常駐登録、電源プランの書き換えは行いません。再起動後は必要なときに手動で起動します。

マウスの指定移動量は左右それぞれ1相対単位です。速度設定や画面端の制限などにより、見える距離や最終位置にはわずかな差が出る場合があります。瞬間的な往復のため、目で見えないこともあります。成功時にはウィンドウに `Mouse nudged.` を表示します。直前確認と送信のごく短い隙間で操作が始まる可能性は残るため、作業への干渉を完全には保証できません。

## スリープ抑止と制約

本体は1秒ごとに `SetThreadExecutionState(ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED)` でWindowsの待機タイマーをリセットします。継続フラグ `ES_CONTINUOUS` を使わないため、終了・強制終了後に抑止要求が残りません。終了後は、最後のリセット時点から通常の自動スリープ・消灯待ち時間に戻ります。画面も点灯を維持するため、電池消費は増えます。

手動スリープ、ふたを閉じる操作、電池切れ、会社の管理設定を上書きする機能ではありません。画面ロック・スクリーンセーバー・会議アプリ等の在席表示の維持は保証しません。判定対象は起動したWindowsログインセッションです。ロック、UAC画面、リモート接続の切断などで入力先を利用できない間は、マウス移動が見送られたり拒否されたりすることがあります。

`Start.cmd` は起動するPowerShellプロセスに限って `-ExecutionPolicy Bypass` を指定します。端末やユーザー全体の実行ポリシーを恒久変更せず、組織のグループポリシーがあればそちらが優先されます。組織の実行制限、署名必須設定、Constrained Language Mode、AppLocker / WDAC等で実行できない場合があります。

## 起動できない・動かないとき

- エラーが出た場合は、そのウィンドウに表示されます。ZIPの中から直接実行せず、3つの実行用ファイルが揃っていることを確認してください。
- 組織の実行制限・署名・権限に関するエラーの場合は、表示内容を管理担当者へ確認してください。
- `Mouse input could not be fully sent` は、Windowsがマウス入力を全部または一部拒否した状態です。スリープ抑止は継続し、次の3分無入力時に再試行します。管理者権限で動く別アプリやセキュアデスクトップなどが原因になりえます。
- 停止するウィンドウが分からないときは、タスクバーで **Idle Keep Awake** のウィンドウを開いて閉じてください。タスクマネージャーで他のPowerShellまでまとめて終了しないでください。

## テスト

`tests/Run-Tests.ps1` は実際の本体のC#を読み込み、OS依存部分を模擬してテストします。実マウスの操作やスリープ設定の変更はありません。追加モジュールは不要です。

```powershell
# Windows PowerShell 5.1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tests\Run-Tests.ps1

# macOS / Linux / Windows の PowerShell 7
pwsh -NoProfile -File ./tests/Run-Tests.ps1
```

自動テストは、180秒の境界、入力再開、6時間の放置、24時間の継続操作、時刻カウンターの折り返し、押しっぱなし、送信拒否、APIエラー、ネイティブ構造体のサイズ、送信イベントを確認します。Windows PowerShell 5.1と実機での起動・マウス・電源APIの動作は、Macのテストだけでは検証できません。検証結果は `VERIFICATION.md` に記載します。

### Windows実機での確認手順（未実施）

1. `Start.cmd` を起動し、`RUNNING` を確認する。再度起動しても本体が増えないことを確認する。
2. 約2分50秒後にキーまたはマウスを操作し、起動から3分時点では動かず、最後の操作から約3分後に `Mouse nudged.` が出ることを確認する。
3. そのままさらに3分放置し、もう1回動くことを確認する。マウスボタンを押しっぱなしにした場合は、動かないことを確認する。
4. 通常の自動消灯・スリープ時間を超えても起動を維持できることを確認する。
5. ウィンドウを閉じ、通常の待ち時間後に自動消灯・スリープへ戻ることを確認する。
6. 画面端・複数画面・ロック／解除・手動スリープからの復帰を、実際に使う環境で確認する。

## 仕様確認に使った公式資料

- [GetLastInputInfo](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getlastinputinfo): セッション内の最終入力時刻。
- [SendInput](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-sendinput)、[INPUT](https://learn.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-input)、[MOUSEINPUT](https://learn.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-mouseinput): 入力送信、構造体、相対移動。
- [GetAsyncKeyState](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getasynckeystate)、[GetCursorPos](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getcursorpos): 押下状態と入力デスクトップの制約。
- [SetThreadExecutionState](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-setthreadexecutionstate): 電源管理の待機タイマーと抑止の限界。
- [PowerShell execution policies](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_execution_policies): プロセス単位の設定と組織ポリシーの優先順位。

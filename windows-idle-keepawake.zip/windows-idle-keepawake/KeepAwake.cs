// C# 5 syntax and .NET Framework APIs for Windows PowerShell 5.1.
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace IdleKeepAwake
{
    public struct InputSnapshot
    {
        public ulong Now;
        public uint LastInput;
        public bool AnyKeyDown;
        public bool CursorAvailable;

        public InputSnapshot(ulong now, uint lastInput, bool anyKeyDown, bool cursorAvailable)
        {
            Now = now;
            LastInput = lastInput;
            AnyKeyDown = anyKeyDown;
            CursorAvailable = cursorAvailable;
        }
    }

    public sealed class IdlePolicy
    {
        public const uint IntervalMilliseconds = 180000;
        private ulong lastAttempt;

        public IdlePolicy(ulong startedAt) { lastAttempt = startedAt; }

        public static uint IdleMilliseconds(ulong now, uint lastInput)
        {
            // LASTINPUTINFO wraps every ~49.7 days. Unsigned subtraction handles it.
            uint elapsed = unchecked((uint)now - lastInput);
            // A future / inconsistent input timestamp must not trigger a movement.
            return elapsed > Int32.MaxValue ? 0 : elapsed;
        }

        public bool IsDue(InputSnapshot state)
        {
            return state.CursorAvailable && !state.AnyKeyDown &&
                state.Now >= lastAttempt &&
                state.Now - lastAttempt >= IntervalMilliseconds &&
                IdleMilliseconds(state.Now, state.LastInput) >= IntervalMilliseconds;
        }

        public void MarkAttempt(ulong now) { lastAttempt = now; }
    }

    public interface IPlatform
    {
        ulong Now { get; }
        InputSnapshot ReadInput();
        void RefreshSleepPrevention();
        bool NudgeMouse();
    }

    public enum TickResult { Waiting, Moved, InputBlocked }

    public sealed class Engine
    {
        private readonly IPlatform platform;
        private readonly IdlePolicy policy;

        public Engine(IPlatform platform)
        {
            if (platform == null) { throw new ArgumentNullException("platform"); }
            this.platform = platform;
            policy = new IdlePolicy(platform.Now);
        }

        public TickResult Tick()
        {
            platform.RefreshSleepPrevention();
            InputSnapshot first = platform.ReadInput();
            if (!policy.IsDue(first)) { return TickResult.Waiting; }

            // Recheck immediately before sending; input may resume during a poll.
            InputSnapshot final = platform.ReadInput();
            if (final.LastInput != first.LastInput || !policy.IsDue(final))
            {
                return TickResult.Waiting;
            }

            // Throttle even if Windows rejects or does not count synthetic input.
            policy.MarkAttempt(final.Now);
            return platform.NudgeMouse() ? TickResult.Moved : TickResult.InputBlocked;
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct MouseInput
    {
        public int dx;
        public int dy;
        public uint mouseData;
        public uint dwFlags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    // MOUSEINPUT is the largest INPUT union member. Its size and alignment also
    // provide the native union's layout: INPUT is 28 bytes on x86, 40 on x64/ARM64.
    [StructLayout(LayoutKind.Sequential)]
    public struct MouseEvent
    {
        public uint type;
        public MouseInput mi;
    }

    public sealed class WindowsPlatform : IPlatform
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct LastInputInfo { public uint cbSize; public uint dwTime; }

        [StructLayout(LayoutKind.Sequential)]
        private struct Point { public int x; public int y; }

        [DllImport("kernel32.dll")]
        private static extern ulong GetTickCount64();

        [DllImport("kernel32.dll")]
        private static extern uint SetThreadExecutionState(uint flags);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetLastInputInfo(ref LastInputInfo info);

        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(int virtualKey);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetCursorPos(out Point point);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern uint SendInput(uint count, [In] MouseEvent[] inputs, int size);

        public ulong Now { get { return GetTickCount64(); } }

        public InputSnapshot ReadInput()
        {
            Point point;
            bool cursorAvailable = GetCursorPos(out point);
            bool held = false;
            if (cursorAvailable)
            {
                // Includes mouse buttons and modifiers; do not move during a drag
                // or a held key. Only the high bit is reliable. No keys are logged.
                for (int key = 1; key <= 254; key++)
                {
                    if (GetAsyncKeyState(key) < 0) { held = true; break; }
                }
            }

            LastInputInfo info = new LastInputInfo();
            info.cbSize = (uint)Marshal.SizeOf(typeof(LastInputInfo));
            if (!GetLastInputInfo(ref info))
            {
                throw new Win32Exception(Marshal.GetLastWin32Error(), "Could not read the last input time.");
            }
            // Read the clock AFTER the input timestamp to avoid an underflow race.
            return new InputSnapshot(Now, info.dwTime, held, cursorAvailable);
        }

        public void RefreshSleepPrevention()
        {
            // ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED, deliberately without
            // ES_CONTINUOUS. Refresh every second, with no thread-bound cleanup.
            if (SetThreadExecutionState(0x00000003) == 0)
            {
                throw new InvalidOperationException("Windows rejected the sleep-prevention request.");
            }
        }

        public static MouseEvent[] CreateNudge()
        {
            MouseEvent[] events = new MouseEvent[2];
            events[0].mi.dx = 1;
            events[1].mi.dx = -1;
            // MOVE | MOVE_NOCOALESCE only: no click, wheel, or keyboard event.
            events[0].mi.dwFlags = events[1].mi.dwFlags = 0x00002001;
            return events;
        }

        public bool NudgeMouse()
        {
            // Submit both relative moves in ONE call. Never restore an old absolute
            // cursor position after a delay, which would overwrite resumed input.
            MouseEvent[] events = CreateNudge();
            return SendInput((uint)events.Length, events, Marshal.SizeOf(typeof(MouseEvent))) == events.Length;
        }
    }
}

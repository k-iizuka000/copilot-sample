#requires -Version 5.1
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$mutex = $null
$ownsMutex = $false

try {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
        throw 'This tool runs only on Windows. Use tests/Run-Tests.ps1 for portable tests.'
    }

    # Local\ scopes the mutex to this Windows sign-in session, across folder copies.
    $mutex = New-Object System.Threading.Mutex($false, 'Local\IdleKeepAwake.3Minutes.v1')
    try {
        $ownsMutex = $mutex.WaitOne(0)
    }
    catch [System.Threading.AbandonedMutexException] {
        $ownsMutex = $true
    }
    if (-not $ownsMutex) {
        Write-Host 'Idle Keep Awake is already running in this sign-in session.'
        Start-Sleep -Seconds 3
        return
    }

    Add-Type -Path (Join-Path $PSScriptRoot 'KeepAwake.cs')
    $platform = New-Object IdleKeepAwake.WindowsPlatform
    $engine = New-Object IdleKeepAwake.Engine($platform)
    # Validate the power API before reporting that startup succeeded.
    $platform.RefreshSleepPrevention()

    $Host.UI.RawUI.WindowTitle = 'Idle Keep Awake - RUNNING - close this window to stop'
    Write-Host 'Idle Keep Awake is RUNNING.' -ForegroundColor Green
    Write-Host 'After 3 minutes without input: a tiny mouse movement out and back.'
    Write-Host 'Keyboard / mouse activity restarts the 3-minute wait.'
    Write-Host 'Automatic sleep and display timeout are suppressed while running.'
    Write-Host 'You can minimize this window. Close it or press Ctrl+C to stop.'
    Write-Host ''
    $inputBlocked = $false

    while ($true) {
        $result = $engine.Tick()
        if ($result -eq [IdleKeepAwake.TickResult]::Moved) {
            Write-Host ('{0:HH:mm:ss}  Mouse nudged.' -f (Get-Date))
            $inputBlocked = $false
        }
        elseif ($result -eq [IdleKeepAwake.TickResult]::InputBlocked -and -not $inputBlocked) {
            Write-Warning 'Mouse input could not be fully sent. Sleep prevention continues; retry after 3 idle minutes.'
            $inputBlocked = $true
        }
        Start-Sleep -Milliseconds 1000
    }
}
catch {
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
finally {
    # No continuous power request is retained: each tick only resets idle timers.
    # Closing/killing this process also ends those resets, even without this finally.
    if ($ownsMutex) { $mutex.ReleaseMutex() }
    if ($null -ne $mutex) { $mutex.Dispose() }
}
